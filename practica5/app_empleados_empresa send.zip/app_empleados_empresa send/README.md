# Análisis de Datos de Empleados

Proyecto para el análisis de datos de empleados, incluyendo limpieza de datos, estadísticas descriptivas y visualización.

## Estructura del Proyecto

```
app_empleados_empresa/
├── data.csv                    # Archivo de datos con información de empleados
├── main.py                     # Script principal que ejecuta el análisis completo
├── analysis/                   # Módulo de análisis
│   ├── __init__.py            # Inicialización del módulo
│   ├── statistics.py          # Funciones estadísticas
│   ├── cleaning.py            # Funciones de limpieza de datos
│   └── visualization.py       # Funciones de visualización
└── README.md                  # Este archivo
```

## Datos

El archivo `data.csv` contiene:
- **nombre**: Nombre del empleado
- **edad**: Edad del empleado (puede contener valores faltantes)
- **salario**: Salario del empleado (puede contener valores faltantes)

## Funcionalidades

### 1. Limpieza de Datos (`analysis/cleaning.py`)

- **`load_data(file_path)`**: Carga datos desde un archivo CSV
- **`identify_missing_values(df)`**: Identifica valores faltantes en edades y salarios
- **`calculate_means_for_missing(df)`**: Calcula medias para reemplazo de valores faltantes
- **`clean_missing_values(df)`**: Reemplaza valores faltantes:
  - Edades faltantes → Media de edades
  - Salarios faltantes → Media de salarios

### 2. Estadísticas (`analysis/statistics.py`)

- **`calculate_statistics(data)`**: Calcula estadísticas descriptivas:
  - Media de edades
  - Media de salarios
  - Edad máxima
  - Edad mínima
  - Desviación estándar de salarios

### 3. Visualización (`analysis/visualization.py`)

- **`plot_age_bar_chart(df)`**: Gráfico de barras de edades por empleado
- **`plot_salary_bar_chart(df)`**: Gráfico de barras de salarios por empleado
- **`plot_combined_chart(df)`**: Gráfico combinado de edades y salarios

## Instalación

### Requisitos

```bash
pip install numpy pandas matplotlib
```

## Uso

### Ejecutar el análisis completo

```bash
python3 main.py
```

El script principal ejecuta:

1. **Carga de datos**: Lee el archivo `data.csv`
2. **Limpieza de datos**: Identifica y reemplaza valores faltantes
3. **Análisis estadístico**: Calcula estadísticas descriptivas
4. **Visualización**: Muestra gráficos de barras

### Ejemplo de uso individual

```python
from analysis.cleaning import load_data, clean_missing_values
from analysis.statistics import calculate_statistics
from analysis.visualization import plot_age_bar_chart

# Cargar y limpiar datos
df = load_data('data.csv')
df_clean = clean_missing_values(df)

# Calcular estadísticas
data = df_clean[['edad', 'salario']].values.tolist()
stats = calculate_statistics(data)

# Mostrar gráfico
plot_age_bar_chart(df_clean)
```

## Salida del Programa

### Datos Originales
```
   nombre  edad  salario
0     Ana  25.0   2000.0
1    Luis  30.0   2500.0
2  Carlos  28.0      NaN
3   Marta  35.0   2700.0
4   Pedro   NaN   2200.0
```

### Datos Limpios
```
   nombre  edad  salario
0     Ana  25.0   2000.0
1    Luis  30.0   2500.0
2  Carlos  28.0   2350.0
3   Marta  35.0   2700.0
4   Pedro  29.5   2200.0
```

### Estadísticas
```
Análisis de datos:
Mean_ages: 29.50
Mean_salary: 2350.00
Max_age: 35.00
Min_age: 25.00
Std_salary: 240.83
```

## Características

- ✅ **Manejo de valores faltantes**: Reemplazo automático con medias
- ✅ **Análisis estadístico**: Cálculo de estadísticas descriptivas
- ✅ **Visualización**: Gráficos de barras para edades y salarios
- ✅ **Modularidad**: Código organizado en módulos funcionales
- ✅ **Fácil extensión**: Estructura modular permite agregar nuevas funcionalidades

## Autor

Proyecto desarrollado para el curso de Maestría en Ciencia de Datos - Clase 5

### Integrantes del equipo:
- Andrea Elizabeth Arana Ore
- Oliver Ronald Camacho Velasco
- Clara Ines Olmedo Rodriguez
- Jorge Luis Torrez Garcia
- Juan Francisco Gareca Aguirre
