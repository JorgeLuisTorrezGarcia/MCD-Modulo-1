from analysis import calculate_statistics
from analysis.cleaning import identify_missing_values, clean_missing_values, load_data
from analysis.visualization import plot_age_bar_chart, plot_salary_bar_chart, plot_combined_chart

def main():
  # Load data from a CSV file
  df = load_data('data.csv')
  print("datos originales: ")
  print(df)

  #clean data / limpiar datos
  df_clean = clean_missing_values(df)
  print("\ndatos limpios: ")
  print(df_clean)

  # analyze data / analizar datos
  # Exclude the 'nombre' column, only use numeric columns
  data = df_clean[['edad', 'salario']].values.tolist()
  stats = calculate_statistics(data)
  
  # print results / imprimir resultados
  print("\nAnálisis de datos: ")
  for key, value in stats.items():
    print(f"{key.capitalize()}: {value:.2f}")

  # show graphs / mostrar gráficos
  print("\nMostrando gráficos...")
  
  # Gráfico de edades
  # plot_age_bar_chart(df_clean)
  
  # Gráfico de salarios
  # plot_salary_bar_chart(df_clean)
  
  # Gráfico combinado
  plot_combined_chart(df_clean)

if __name__ == "__main__":
  main()