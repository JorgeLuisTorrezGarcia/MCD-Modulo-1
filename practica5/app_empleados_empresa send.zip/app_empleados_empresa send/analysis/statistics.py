import numpy as np
import pandas as pd

def calculate_statistics(data):

    """
    Calculate basic statistics for a list of numbers
    :param data: List of numbers
    :return: Dictionary with mean, median, variance, and standard deviation
    """
    data = np.array(data)

    statistics =  {
        'mean_ages': np.mean(data[:, 0]),
        'mean_salary': np.mean(data[:, 1]),
        'max_age': np.max(data[:, 0]),
        'min_age': np.min(data[:, 0]),
        'std_salary': np.std(data[:, 1])
    }
    return statistics


