from unicodedata import numeric
import pandas as pd


def load_data(file_path):
  """ Load data from a CSV file """  
  return pd.read_csv(file_path)


def identify_missing_values(df):
    """
    Identify missing values in the dataset
    :param df: pandas DataFrame
    :return: Dictionary with missing values count for each column
    """
    missing_values = {
        'missing_ages': df['edad'].isna().sum(),
        'missing_salaries': df['salario'].isna().sum()
    }
    return missing_values

def calculate_means_for_missing(df):
    """
    Calculate mean values for ages and salaries (ignoring missing values)
    :param df: pandas DataFrame
    :return: Dictionary with mean values
    """
    means = {
        'mean_age': df['edad'].mean(),
        'mean_salary': df['salario'].mean()
    }
    return means


def clean_missing_values(df):
  """ Replace missing values with the mean of each column using statistics.py functions """
  
  # Identify missing values
  missing_info = identify_missing_values(df)
  
  # Calculate means for replacement
  means = calculate_means_for_missing(df)
  
  # Replace missing values
  df_cleaned = df.copy()
  df_cleaned['edad'] = df_cleaned['edad'].fillna(means['mean_age'])
  df_cleaned['salario'] = df_cleaned['salario'].fillna(means['mean_salary'])
  
  return df_cleaned
