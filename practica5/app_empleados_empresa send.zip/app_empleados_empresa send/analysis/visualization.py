import matplotlib.pyplot as plt

# def plot_age_distribution(df):
#     plt.figure(figsize=(10, 6))
#     plt.hist(df['edad'], bins=10, color='skyblue', edgecolor='black')
#     plt.title('Distribución de Edades')
#     plt.xlabel('Edad')
#     plt.ylabel('Frecuencia')
#     plt.show()

def plot_age_bar_chart(df):
    """Gráfico de barras de edades por empleado"""
    plt.figure(figsize=(10, 6))
    plt.bar(df['nombre'], df['edad'], color='skyblue', edgecolor='black')
    plt.title('Edades de Empleados')
    plt.xlabel('Empleado')
    plt.ylabel('Edad')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot_salary_bar_chart(df):
    """Gráfico de barras de salarios por empleado"""
    plt.figure(figsize=(10, 6))
    plt.bar(df['nombre'], df['salario'], color='lightgreen', edgecolor='black')
    plt.title('Salarios de Empleados')
    plt.xlabel('Empleado')
    plt.ylabel('Salario')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot_combined_chart(df):
    """Gráfico combinado de edades y salarios"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Gráfico de edades
    ax1.bar(df['nombre'], df['edad'], color='skyblue', edgecolor='black')
    ax1.set_title('Edades de Empleados')
    ax1.set_xlabel('Empleado')
    ax1.set_ylabel('Edad')
    ax1.tick_params(axis='x', rotation=45)
    
    # Gráfico de salarios
    ax2.bar(df['nombre'], df['salario'], color='lightgreen', edgecolor='black')
    ax2.set_title('Salarios de Empleados')
    ax2.set_xlabel('Empleado')
    ax2.set_ylabel('Salario')
    ax2.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.show()
